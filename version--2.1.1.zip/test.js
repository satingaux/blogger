const mongoose = require('mongoose')

const Post = require('./database/models/Post')

try {
  mongoose.connect('mongodb://localhost/node-js-test-blog', { useNewUrlParser: true })
    .then(
    	Post.find({
		
	},(error,post) => {
	console.log(error,post)
})

)
    .catch(e => console.error(`.catch(${e})`));
} catch (e) {
  console.error(`try/catch(${e})`);
}
// try {
//   mongoose.connect('mongodb://localhost/node-js-test-blog', { useNewUrlParser: true })
//     .then(
//     	Post.create({

// 		title: 'My First blog post',
// 		description: 'DESCRIPTION',
// 		content: 'CONTENT'

// 	},(error,post) => {
// 	console.log(error,post)
// })

// )
//     .catch(e => console.error(`.catch(${e})`));
// } catch (e) {
//   console.error(`try/catch(${e})`);
// }
// mongoose.connect('mongodb://localhost/node-js-test-blog', { useNewUrlParser: true }).then(() => {
//     console.log("Connected to Database");
// }).catch((err) => {
//     console.log("Not Connected to Database ERROR! ", err);
// });
// mongoose.connect('mongodb://localhost/node-js-test-blog')

// Post.create({

// 	title: 'My First blog post',
// 	description: 'DESCRIPTION',
// 	content: 'CONTENT'
// },(error,post) => {
// 	console.log(error,post)
// })
