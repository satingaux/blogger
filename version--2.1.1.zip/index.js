const express= require('express')
const expressEdge = require('express-edge')
const mongoose = require('mongoose')
const bodyParser=require('body-parser')
const Post = require('./database/models/Post')
const fileUpload = require('express-fileupload')
const connectMongo = require('connect-mongo')
const expressSession = require('express-session')
const connectFlash = require('connect-flash')


const createPostController = require('./controllers/createPost')
const homePageController = require('./controllers/homepage')
const storePostController = require('./controllers/storePost.js')
const getPostController = require('./controllers/getPost')
const createUserController = require('./controllers/createUser')
const storeUserController = require('./controllers/storeUser')
const loginController = require('./controllers/login')
const loginUserContoller = require('./controllers/loginUsers')
const logoutController = require('./controllers/logout')

const storePost = require('./middleware/storePost')
const auth = require('./middleware/auth')
const redirectAuthentication = require('./middleware/redirectAuthenticated')

const app = new express()
const edge= require('edge.js')

try{
	mongoose.connect('mongodb://localhost/node-js-blog',  { useNewUrlParser: true })
 } catch (e) {
  console.error(`try/catch(${e})`);
}

const mongoStore = connectMongo(expressSession);

app.use(
  expressSession({
    secret: 'secret',
    store: new mongoStore({
      mongooseConnection: mongoose.connection
    })
  })
)
app.use(fileUpload())
app.use(express.static('public'))
app.use(require('express-edge'))
app.use(bodyParser.json())
app.use(connectFlash());

app.use(bodyParser.urlencoded({ extended: true }))

// app.set('views', '${__dirname}/views')
app.set('views', __dirname +'/views')

app.use('*', (req, res, next) => {
	edge.global('auth', req.session.userId)
	next()
})

app.get('/', homePageController)

app.get('/post/:id', getPostController);

app.get('/auth/logout', auth, logoutController)

app.get('/posts/new', auth, createPostController);

app.post('/posts/store', auth, storePost, storePostController);

app.get('/auth/login', redirectAuthentication, loginController)

app.post('/users/login', redirectAuthentication, loginUserContoller)

app.get('/auth/register' , redirectAuthentication, createUserController);

app.post('/users/register', redirectAuthentication, storeUserController);	


// app.use('/posts/store',storePost)

// app.use('/posts/new', auth)


app.use((req,res) => res.render('404'));



app.listen(3000, () => {
	console.log('All listen at port 3000')
})