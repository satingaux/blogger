const mongoose = require('mongoose')

const PostSchema = new mongoose.Schema({

	title: String,

	location: String,

	description: String,

	image: String,

	auther: {
		type: mongoose.Schema.Types.ObjectId,
		ref: 'User',
		required: true
	},

	createdAt: {
		type: Date,
		default: new Date()
	}
})

const Post = mongoose.model('Post', PostSchema)

module.exports = Post