

module.exports =  (req, res, next) => {
	// console.log("i have been called")								!req.files.image ||
	if(  !req.body.title || !req.body.location || !req.body.description){
		return res.redirect('/posts/new')
	}
	next()
}