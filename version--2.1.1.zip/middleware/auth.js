const User =require('../database/models/User')

module.exports = (req,res,next) => {
	User.findById(req.session.userId, (error, user) => {
		if(error || !user ) {

			// const registrationErrors =Object.keys(error.errors).map (key => error.errors[key].message);
			// req.session.registrationErrors = registrationErrors
			return  res.redirect('/')
		}

		next()
	})
}	