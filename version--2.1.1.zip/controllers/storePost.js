const path = require('path')
const Post= require('../database/models/Post')

module.exports = (req, res) => {
	// console.log(req.files)
	const  image  = req.files.image
	// image.mv(path.resolve(__dirname, './public/posts', image.name), (error) => {

	image.mv(path.resolve(__dirname,'../public/posts', image.name), (error) => {

		Post.create({

			...req.body,
			image: ('/posts/'+ image.name),
			
			auther: req.session.userId

		}, (error,post) => {
		// console.log(req.body)
		res.redirect('/');

	    });
	});
}