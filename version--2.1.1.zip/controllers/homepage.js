const Post = require('../database/models/Post')

module.exports = async (req, res) => {
	// res.render('index')
	const posts = await Post.find({}).populate('auther');
	// console.log(posts)
	res.render('index',{
		posts
	})
}